from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Product
from django.contrib import messages
from django.contrib.auth.models import User, auth
# Create your views here.
def index(request):
    return render(request, 'myhome/index.html')

def signup(request):
    if request.method== 'POST':
        user_name = request.POST['user_name']
        password = request.POST['password']

        user = auth.authenticate(request, username=user_name,password=password)

        if user is not None:
            auth.login(request, user)
            return redirect("/")
        else:
            messages.info(request,'invalid credentials')
            return redirect('signup')

    else:
        return render(request,'myhome/login.html')    

def signup(request):

    if request.method == 'POST':
        user_name = request.POST['user_name']
        email_address = request.POST['email_address']
        mobile_number = request.POST['mobile_number']
        pincode = request.POST['pincode']
        state = request.POST['state']
        password = request.POST['password']
        repeat_password = request.POST['repeat_password']

        if password==repeat_password:
            if User.objects.filter(username=user_name).exists():
                messages.info(request,'Username Taken')
                return redirect('/')
            elif User.objects.filter(email=email_address).exists():
                messages.info(request,'Email Taken')
                return redirect('/')
            else:   
                user = User.objects.create_user(username=user_name, password=repeat_password, email=email_address)
                user.save()
                print('user created')
                return redirect('/')

        else:
            messages.info(request,'password not matching..')    
            return redirect('/')
            
        
        
    else:
        return render(request, 'myhome/login.html')



def logout(request):
    auth.logout(request)
    return redirect('/')   


def about(request):
    return render(request, 'myhome/about.html')

def contact(request):
   return render(request, 'myhome/contact.html')  

def blog(request):
    return render(request, 'myhome/blog.html')    

def serve(request):
   return render(request, 'myhome/services.html') 

def sell(request):
   return render(request, 'myhome/sell.html')    
    
def buy(request):
    return render(request, 'myhome/Buy.html')    
    
def cart(request):
    return render(request, 'myhome/cart.html')    

def productlist(request):
    return render(request, 'myhome/product.html')

